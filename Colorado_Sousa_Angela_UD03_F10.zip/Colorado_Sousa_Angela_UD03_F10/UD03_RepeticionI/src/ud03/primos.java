package ud03;
import java.util.Scanner;
public class primos {
    public static void main(String[] args) {
        //¿Es primo? Pide un número y di si es primo. Usa una variable boolean de bandera y corta la búsqueda de divisores en cuanto encuentres uno.
        Scanner sc = new Scanner(System.in);
        int numPrimo = 0;
        System.out.print("Introduzca un número: ");
        numPrimo = sc.nextInt();
        int i = 2;

        boolean esPrimo = i > 1;

        while (esPrimo) {

        }
    }
}
