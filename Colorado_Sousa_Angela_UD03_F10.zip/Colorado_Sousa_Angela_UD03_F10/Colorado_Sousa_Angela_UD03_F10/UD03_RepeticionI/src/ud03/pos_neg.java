package ud03;
import java.util.Scanner;
public class pos_neg {
    public static void main (String[] args) {
        //Positivos y negativos. Lee diez números y muestra cuántos son positivos y cuántos negativos (el cero no es ninguno de los dos: decide tú qué hacer con él y coméntalo).
        Scanner sc = new Scanner(System.in);
        int numIntro;
        //Contadores:
        int positivos = 0;
        int negativos = 0;
        int reps = 1;

        while (reps <= 10) {
            System.out.print("\nIntroduce un número: ");
            numIntro = sc.nextInt();
            reps++;//Da vueltas hasta que las repeticiones lleguen a 10, después cuenta los números menor que cero como negativos y los mayores como positivos.

            if (numIntro == 0) {
                System.out.print("No es un número válido. ");
                continue;
            } else if (numIntro > 0) {
                positivos++;
            } else {
                negativos++;
            }

        }
        System.out.print(positivos + " son positivos.");
        System.out.print(negativos + " son negativos.");

        sc.close();
    }
}

