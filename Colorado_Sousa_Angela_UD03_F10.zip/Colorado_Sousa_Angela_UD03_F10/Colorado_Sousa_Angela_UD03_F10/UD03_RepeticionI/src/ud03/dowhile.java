package ud03;
import java.util.Scanner;
public class dowhile {
    public static void main(String[] args) {
        //Validación con do-while. Pide un número entero positivo. Si el usuario escribe un valor no válido, el programa lo pide otra vez; cuando ya sea válido, muestra la suma de los 100 enteros siguientes a él (n+1 + n+2 + … + n+100).

        Scanner sc = new Scanner(System.in);
        int num = 0;

        do {
            System.out.print("Introduce un número entero positivo: ");
            num = sc.nextInt();
        } while (num <= 0);

        int suma = 0;

        for (int i = 1; i <= 100; i++) {
            suma += num + i;
        }
        System.out.print("La suma de los 100 enteros siguientes a su número es: " + suma);

        sc.close();
    }

}
