package ud03;
import java.util.Scanner;
public class media {
    public static void main(String[] args) {
        //Media con centinela. Pide números positivos y ve sumándolos; cuando el usuario introduzca un número negativo, el programa deja de pedir y muestra la media de los números introducidos y cuántos eran. El negativo no cuenta.
        Scanner sc = new Scanner(System.in);
        System.out.print("Introduce un número positivo: ");
        int num = sc.nextInt();
        int suma = 0;
        int numIntro = 0;

        while (num>=0) {
            suma += num;

            System.out.print("Introduce un número positivo: ");
            num = sc.nextInt();
            numIntro++;

        }
        if (num < 0) {
            int media = suma / numIntro;
            System.out.print("Números introducidos: " + numIntro + "\nLa media es: " + media);
        }
        sc.close();
    }
}
