package ud03;
import java.util.Scanner;
public class primos {
    public static void main(String[] args) {
        //¿Es primo? Pide un número y di si es primo. Usa una variable boolean de bandera y corta la búsqueda de divisores en cuanto encuentres uno.
        Scanner sc = new Scanner(System.in);
        System.out.print("Introduzca un número: ");
        int numero = sc.nextInt();
        int division = 2;
        boolean primo = true; //Se va a asumir que todo número es primo hasta que se encuentren divisores.

        if (numero < 2) { //los primos no pueden ser negativos y menor que 2, porque 2 es el primer número primo que existe.
            primo = false;
        }

        while (division < numero && primo) { //Revisar los divisores
            if (numero % division == 0) {
                primo = false;
            }
            division++;
        }
        if (primo) {
            System.out.print("El número es primo.");
        } else {
            System.out.print("El número no es primo.");
        }
        sc.close();
    }
}
