import java.util.Scanner;

public class EJ3 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        //Crea un algoritmo que lea dos números, calcule y muestre el valor de su suma, resta, producto y división

        System.out.println("Introduzca un número: ");
        double numero1 = sc.nextDouble();
        System.out.println("Introduzca otro número: ");
        double numero2 = sc.nextDouble();

        double suma = numero1 + numero2 ;
        double resta = numero1 + numero2 ;
        double division = numero1 / numero2;
        double multipli = numero1 * numero2;

        System.out.println("Los números suman: " + suma);
        System.out.println("La resta de los números es: " + resta);
        System.out.println("El producto de los números es: " + multipli);
        System.out.println("La división de los números es: " + division);

        sc.close();
    }
}
