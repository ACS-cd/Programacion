import java.util.Scanner;

public class EJ5 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
  /*  Crea un algoritmo que lea un valor correspondiente a una distancia en millas marinas y escriba la distancia en
metros. Sabiendo que una milla marina equivale a 1.852 metros.
   */

        System.out.println("Introduce un número de millas: ");
        int millas = sc.nextInt();
        int metros = millas * 1852;
        System.out.println(millas + " millas equivalen a " + metros + " metros. ");

        sc.close();
    }
}
