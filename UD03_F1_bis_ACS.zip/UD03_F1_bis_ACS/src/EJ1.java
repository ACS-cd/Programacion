import java.util.Scanner;

//Calcula el número de horas que hay en un número de años introducido por teclado.
public class EJ1{
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Introduzca un número de años: ");
        int years = sc.nextInt();
        // horas en 365 días = 8760
        int horasTotal = 8760*years;

        System.out.println("Hay " + horasTotal + " horas en los años introducidos.");
        sc.close();
    }
}

