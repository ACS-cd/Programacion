import java.util.Scanner;

public class EJ13 {
    public static void main(String[] args) {

/*Escribe un programa que calcule el total de una factura a partir de la base imponible (precio sin IVA). La base
imponible estará almacenada en una variable.
 */
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduzca el importe base: ");
        double facturaBase = sc.nextDouble();
        double iva = facturaBase*0.21;
        double total = facturaBase + iva ;

        System.out.printf("El total del importe con IVA es de: %.2f%n", total);

    }
}
