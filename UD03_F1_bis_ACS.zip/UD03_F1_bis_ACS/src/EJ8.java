import java.util.Scanner;
public class EJ8 {
    public static void main(String[] args) {
        /* Realiza un programa que te calcule el promedio de las notas de un alumno. Para ello el programa te va a tener
que solicitar el nombre del alumno y las notas de las 3 evaluaciones.
         */
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduzca el nombre del alumno :");
        String nombreAlumno = sc.next();
        System.out.println("Introduzca la nota de la 1º Evaluación: ");
        double nota1EV = sc.nextDouble();
        System.out.println("Introduzca la nota de la 2º Evaluación: ");
        double nota2EV = sc.nextDouble();
        System.out.println("Introduzca la nota de la 3º Evaluación: ");
        double nota3EV = sc.nextDouble();
        double mediaNotas = (nota1EV + nota2EV + nota3EV)/3;
        System.out.println("La nota media del alumno es " + mediaNotas + ".");

        sc.close();
    }
}
