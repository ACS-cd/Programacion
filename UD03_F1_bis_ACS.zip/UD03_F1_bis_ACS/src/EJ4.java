import java.util.Scanner;

public class EJ4 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

    /*Crea un algoritmo que toma como dato de entrada un número que corresponde a la longitud de un radio y nos
escribe la longitud de la circunferencia, el área del círculo y el volumen de la esfera que corresponden con dicho
radio.
     */
        System.out.println("Introduzca la longitud del radio: ");
        double radio = sc.nextDouble();

        double circunferencia = (2*3.14)*radio;
        double areaCirculo = (radio * 2 )* 3.14;

        double r3 = radio*radio*radio;
        double volumeEsfera = 4/3 * 3.14 * r3;

        System.out.println("La longitud de la circunferencia es " + circunferencia);
        System.out.println("El área del círculo es " + areaCirculo);
        System.out.println("El volúmen de la esfera es " + volumeEsfera);
        sc.close();
    }
}
