import java.util.Scanner;

public class EJ2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in); //Declaración del escáner.
        //*Calcula el área de un cuadrado cuyo valor de cada lado es introducido por pantalla. Muestra el resultado por pantalla.
        System.out.println("Introduce la longitud del lado de un cuadrado: ");
        int longitud = sc.nextInt();
        int area = longitud*longitud;

        System.out.println("El área del cuadrado es: " + area);
        sc.close();
    }
}
