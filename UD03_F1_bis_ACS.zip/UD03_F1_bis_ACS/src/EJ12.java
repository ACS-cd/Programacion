public class EJ12 {
    public static void main(String[] args) {

        System.out.println("  /\\ ___ /\\");
        System.out.println(" (  o   o  )");
        System.out.println("  \\  >#<  /");
        System.out.println("  /       \\");
        System.out.println(" /         \\      ^");
        System.out.println("|           |    //");
        System.out.println(" \\         /   //");
        System.out.println("  ///  ///  --");
    }
}
