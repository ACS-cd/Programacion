import java.util.Scanner;

public class EJ7 {
    public static void main(String[] args) {
        //Solicita al usuario su peso y altura, y calcula su índice de masa corporal (BMI).

        Scanner sc = new Scanner(System.in);
        System.out.println("Introduzca su peso: ");
        double peso = sc.nextDouble();
        System.out.println("Introduzca su altura: ");
        double altura = sc.nextDouble();
        double bmi = peso/(altura*altura);
        System.out.println("Su BMI es: " + bmi);

        sc.close();
    }
}
