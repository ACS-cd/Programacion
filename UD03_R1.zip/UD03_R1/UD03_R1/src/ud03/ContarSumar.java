package ud03;
import java.util.Scanner;
class ContarSumar {
    public static void main(String[] args){
        int contador = 0;
        int acumulador = 0;

        Scanner sc= new Scanner(System.in);

        System.out.print("Introduce un número: ");
        int numero = sc.nextInt();

        while (numero != 0) {

            acumulador += numero;
            contador++;

            System.out.print("Introduce un número: ");
            numero = sc.nextInt();
        }
        System.out.print("Números leídos: " + contador + "\nSuma total: " + acumulador);
    }
}
