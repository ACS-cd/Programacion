package ud03;
import java.util.Scanner;
public class Gastos {
    public static void main (String[] args) {
        int opcion = -1;
        Scanner sc = new Scanner(System.in);
        //Todo se declara fuera del bucle para evitar problemas de malas cuentas, cifras que se borran en cada vuelta, etc.
        double importe = 0;
        int contador = 0;
        double total = 0;

        while ( opcion != 0) { //El bucle se inicia siempre por ser -1 en vez de 0.
            System.out.print("\n1-Añadir gasto\n2-Ver total\n3-Ver número de gastos\n0-FIN\n");
            System.out.print("Introduzca una opción: ");
            opcion = sc.nextInt();
            switch (opcion) {
                case 1:
                    System.out.print("Introduce un importe: ");
                    importe = sc.nextDouble();
                    if (importe <= 0) {
                        System.out.print("El importe debe ser mayor que cero.");
                    } else {
                        total += importe;
                        contador ++;
                    }
                    break;
                case 2:
                    System.out.printf("Total: %.2f%n" , total);
                    break;
                case 3:
                    System.out.print("Gastos registrados: " + contador);
                    break;
                case 0:
                    break;
                default:
                    System.out.print("Opción no válida.");
            }
        }
        System.out.print("\nPrograma terminado.");
        sc.close();
    }
}
