package ud03;
import java.util.Scanner;
public class semana {
    public static void main(String[] args) {
//Día de la semana. Pide un número del 1 al 7 y muestra el día que le corresponde (lunes, martes…). Si el número está fuera de rango, muestra Numero no valido. Usa switch.
    System.out.print("Introduce un número del 1 al 7: ");
    Scanner sc = new Scanner(System.in);
    int dia = sc.nextInt();

    switch (dia) {

        case 1:
            System.out.println("Lunes");
            break;

        case 2:
            System.out.println("Martes");
            break;

        case 3:
            System.out.println("Miércoles");
            break;

        case 4:
            System.out.println("Jueves");
            break;

        case 5:
            System.out.println("Viernes");
            break;

        case 6:
            System.out.println("Sábado");
            break;

        case 7:
            System.out.println("Domingo");

        default:
            System.out.println("Número no válido.");
            break;
    }
    sc.close();
    }
}
