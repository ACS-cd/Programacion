package ud03;
import java.util.Scanner;
public class mes {
    public static void main(String[] args) {
//Días del mes. Pide un número de mes (1 a 12) y muestra cuántos días tiene. Usa un solo switch agrupando los casos que comparten respuesta (31 días: 1, 3, 5, 7, 8, 10, 12; 30 días: 4, 6, 9, 11; febrero: 28).

        Scanner sc = new Scanner(System.in);
        System.out.print("Introduce un número de mes: ");
        int mes = sc.nextInt();

        switch (mes) {
            case 1, 3, 5, 7, 8, 10, 12:
                System.out.println("El mes " + mes + " tiene 31 días.");
                break;

            case 2:
                System.out.println("El mes " + mes + " tiene 28 días.");
                break;

            case 4, 6, 9, 11:
                System.out.println("El mes " + mes + " tiene 30 días.");
                break;

            default:
                System.out.println("Número inválido.");
                break;
        }
        sc.close();
    }
}
