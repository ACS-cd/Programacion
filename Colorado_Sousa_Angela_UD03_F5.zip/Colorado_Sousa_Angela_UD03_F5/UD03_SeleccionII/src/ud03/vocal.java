package ud03;
import java.util.Scanner;
public class vocal {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
 //Vocal o consonante. Pide un solo carácter y muestra Es una vocal o Es una consonante. Usa switch sobre el carácter (agrupando las cinco vocales en el mismo caso) y un default para las consonantes

         System.out.print("Introduce una letra del abecedario: ");
         char letra = sc.next().charAt(0);

         switch (letra) {
             case 'a', 'e', 'i', 'o', 'u':
                 System.out.print(letra + " es una vocal.");
                 break;
             default:
                 System.out.print(letra + " es una consonante.");
                 break;
        }

    //Funciona, pero acoge carácteres extras como puntos y comas cual si fueran consonantes.
        sc.close();
    }
}
