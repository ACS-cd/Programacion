package ud03;
import java.util.Scanner;
public class edad {
    public static void main(String[] args) {
        /*Clasificación por edad. Pide una edad, comprueba primero que no es negativa (si lo es, muestra Edad no valida) y clasifícala en Niño/a (menos de 13), Adolescente (13 a 17), Adulto/a (18 a 64) o Senior (65 o más). Resuélvelo con if-else if-else y añade un comentario de una línea explicando por qué aquí no se puede usar switch.*/
        System.out.print("Introduzca su edad: ");
        Scanner sc = new Scanner(System.in);
        int edad = sc.nextInt();
// Es necesario usar cadenas de if-else porque un switch no acepta condiciones. Es decir no puede ser switch (edad) { case (<13). Tendría que switch (edad) { case 13.

        if (edad<0) {
            System.out.print("Edad no válida.");
        } else if (edad <13) {
            System.out.print("Niño");
        } else if (edad >=13 && edad <= 17) {
            System.out.print("Adolescente");
        } else if (edad >=18 && edad <=64) {
            System.out.print("Adulto.");
        } else if (edad >=65) {
            System.out.print("Senior");
        }
        sc.close();
    }
}
