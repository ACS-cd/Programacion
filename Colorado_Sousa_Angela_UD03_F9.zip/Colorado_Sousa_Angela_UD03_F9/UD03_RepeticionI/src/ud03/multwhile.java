package ud03;

public class multwhile {
    public static void main(String[] args) {
        //Múltiplos de 5 con while. El mismo resultado que el ejercicio 1, pero con while. Al terminar, escribe como comentario una línea diciendo qué te ha costado cambiar.
        int num = 0; //declarar fuera, en el for es dentro.

        while (num <= 100) {
            System.out.print(num + "\t");
            num += 5;
        }
    }
}
