package ud03;

public class cuenta {
    public static void main(String[] args) {
        //Cuenta atrás. Muestra los números del 320 al 160, contando de 20 en 20 hacia atrás (320, 300, 280… hasta 160).
        for (int num = 320; num >= 160; num -= 20) {
            System.out.print(num + "\t");
        }

    }
}
