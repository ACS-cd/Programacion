package ud03;

public class acumu5 {
    public static void main(String[] args) {
        //Acumulador y contador. Suma todos los números pares del 1 al 100 y muestra también cuántos son. Deben salir dos datos: la suma y la cantidad.
        int suma = 0;
        int contador = 0;

        for (int num = 1; num <= 100; num++) {
            if (num % 2 == 0 ) {
                suma += num;
                contador++;
            }
        }
        System.out.print("Suma: " + suma);
        System.out.print("\nContador: " + contador);
    }
}
