package ud03;

public class multfor {
    public static void main(String[] args) {
        // Múltiplos de 5 con for. Muestra en una sola línea los múltiplos de 5 de 0 a 100, separados por un espacio.

        for (int num = 0; num <= 100; num += 5) {
            System.out.print(num + "\t"); //tabula de forma automática.
        }
    }
}
