package ud03;
import java.util.Scanner;
public class tabla {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Introduce un número: ");
        int num = sc.nextInt();

        for (int multi = 1; multi <= 10; multi++) {
            System.out.print(num + " x " + multi + " = " + (num*multi) + "\n");
        }
        sc.close();
    }
}
