public class dos {
    public static void main (String[] args) {
       //Muestra los números múltiplos de 5 de 0 a 100 utilizando un bucle while.
        int num = 0;

        while (num <= 100) {
            System.out.print(num + "\t");
            num += 5;

        }
    }
}
