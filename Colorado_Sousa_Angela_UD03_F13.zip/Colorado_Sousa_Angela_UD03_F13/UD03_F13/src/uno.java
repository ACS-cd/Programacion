class uno {
    public static void main(String[] args) {
        //Muestra los números múltiplos de 5 de 0 a 100 utilizando un bucle for

        for (int num = 0; num <= 100; num+= 5) {
            System.out.print(num + "\t");

        }
    }
}