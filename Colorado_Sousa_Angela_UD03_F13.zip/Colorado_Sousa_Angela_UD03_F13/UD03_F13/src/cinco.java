import java.util.concurrent.ThreadLocalRandom;
import java.util.Scanner;
public class cinco {
    public static void main(String[] args) {
        /*Realiza el control de acceso a una caja fuerte. La combinación será un número de 4
cifras. El programa nos pedirá la combinación para abrirla. Si no acertamos, se nos
mostrará el mensaje “Lo siento, esa no es la combinación” y si acertamos se nos dirá
“La caja fuerte se ha abierto satisfactoriamente”. Tendremos cuatro oportunidades
para abrir la caja fuerte. */
        Scanner sc = new Scanner(System.in);

        System.out.print("Introduce la combinación: ");
        int comb = sc.nextInt();
        int num = ThreadLocalRandom.current().nextInt(1000, 9999); //cambiar a (1, 10) para comprobar que funciona.
        int contador = 4;

            do { //he considerado do-while como viable para este ejemplo, aunque también se puede utilizar for.
                System.out.print("Lo siento, esa no es la combinación.\nIntroduce la combinación: ");
                comb = sc.nextInt();
                contador -= 1;
                break;
            } while (contador <= 0 || comb != num);
        System.out.print("La caja se ha abierto satisfactoriamente.");
    }
}
