public class tres {
    public static void main (String[] args) {
        /*Muestra los números del 320 al 160, contando de 20 en 20 hacia atrás utilizando un
bucle for. */

        for ( int num = 320; num >= 160; num-=20) {
            System.out.print(num + "\t");
        }
    }
}
