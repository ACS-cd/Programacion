public class cuatro {
    public static void main(String [] args) {
        /*Muestra los números del 320 al 160, contando de 20 en 20 hacia atrás utilizando un
bucle while. */
        int num = 320;

        while (num >= 160) {
            System.out.print(num + "\t");
            num -= 20;
        }
    }
}
