import java.util.Scanner;
public class diez {
    public static void main(String [] args) {
     /*  Realiza un programa que sume los 100 números siguientes a un número entero y
positivo introducido por teclado. Se debe comprobar que el dato introducido es
correcto (que es un número positivo)   */
            Scanner sc = new Scanner(System.in);
            int num = 0;

            do {
                System.out.print("Introduce un número entero positivo: ");
                num = sc.nextInt();
            } while(num <= 0);

            int suma = 0;

            for(int i = 1; i <= 100; ++i) {
                suma += num + i;
            }

            System.out.print("La suma de los 100 enteros siguientes a su número es: " + suma);
            sc.close();
    }
}
