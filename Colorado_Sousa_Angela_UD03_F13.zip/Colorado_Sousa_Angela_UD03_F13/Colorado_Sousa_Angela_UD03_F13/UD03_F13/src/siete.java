import java.util.Scanner;

public class siete {
    public static void main(String[] args) {
        /*Escribe un programa que calcule la media de un conjunto de números positivos
introducidos por teclado. A priori, el programa no sabe cuántos números se
introducirán. El usuario indicará que ha terminado de introducir los datos cuando
meta un número negativo
*/
            Scanner sc = new Scanner(System.in);
            System.out.print("Introduce un número positivo: ");
            int num = sc.nextInt();
            int suma = 0;

            int numIntro;
            for(numIntro = 0; num >= 0; ++numIntro) {
                suma += num;
                System.out.print("Introduce un número positivo: ");
                num = sc.nextInt();
            }
            if (num < 0) {
                int media = suma / numIntro;
                System.out.print("Números introducidos: " + numIntro + "\nLa media es: " + media);
            }
            sc.close();
    }
}
