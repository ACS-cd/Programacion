import java.util.Scanner;

public class ocho {
    public static void main (String [] args) {
        /*Escribe un programa que lea una lista de diez números y determine cuántos son
positivos, y cuántos son negativos.*/
        Scanner sc = new Scanner(System.in);
        int positivos = 0;
        int negativos = 0;
        int reps = 1;

        while(reps <= 10) {
            System.out.print("\nIntroduce un número: ");
            int numIntro = sc.nextInt();
            ++reps;
            if (numIntro == 0) {
                System.out.print("No es un número válido. ");
            } else if (numIntro > 0) {
                ++positivos;
            } else {
                ++negativos;
            }
        }

        System.out.print(positivos + " son positivos.");
        System.out.print(negativos + " son negativos.");
        sc.close();
    }
}
