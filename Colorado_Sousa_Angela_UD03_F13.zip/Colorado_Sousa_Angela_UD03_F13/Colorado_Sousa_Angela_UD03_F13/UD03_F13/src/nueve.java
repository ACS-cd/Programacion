import java.util.Scanner;

public class nueve {
    public static void main (String[] args) {
        /* Escribe un programa que diga si un número introducido por teclado es o no primo.
Un número primo es aquel que sólo es divisible entre él mismo y la unidad.*/
        Scanner sc = new Scanner(System.in);
        System.out.print("Introduzca un número: ");
        int numero = sc.nextInt();
        int division = 2;
        boolean primo = true;
        if (numero < 2) {
            primo = false;
        }

        for(; division < numero && primo; ++division) {
            if (numero % division == 0) {
                primo = false;
            }
        }

        if (primo) {
            System.out.print("El número es primo.");
        } else {
            System.out.print("El número no es primo.");
        }

        sc.close();
    }
}
