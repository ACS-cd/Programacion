import java.util.Scanner;
public class doce {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int num = 0;

        System.out.print("Introduzca un número: ");
        num = sc.nextInt();
        int inverso = 0;
        int resto;

        while (num > 0) {
            resto = num % 10; //Se queda con la última cifra. EJ: En 1234, se queda con el 4.
            inverso = inverso * 10 + resto; //EJ: 0 * 10 + 4 = 4 en la primera vuelta. Segunda vuelta: inv = 4 * 10 + 3= 43.
            num = num / 10;
        }
        /* Esta fórmula lo que hace es desplazar la coma de sitio.
        ej: 1234
        1234 =
             4000
              200
               30
                1
         */
        System.out.print(inverso + ".");
    }
}
