import java.util.Scanner;
public class once {
    public static void main (String [] args) {
        /* Escribe un programa que obtenga los números enteros comprendidos entre dos
números introducidos por teclado y validados como distintos, el programa debe
empezar por el menor de los enteros introducidos e ir incrementando de 7 en 7.  */

        Scanner sc = new Scanner(System.in);
        int num1, num2, menor, mayor;
        do {
            System.out.print("Introduce el primer número entero: ");
            num1 = sc.nextInt();

            System.out.print("Introduce el segundo número entero: ");
            num2 = sc.nextInt();

            if (num1 == num2) {
                System.out.println("Error: los números deben ser distintos.");
            }
        } while (num1 == num2);

        // Aquí se ordenan los números.
        if (num1 < num2) {
            menor = num1;
            mayor = num2;
        } else {
            menor = num2;
            mayor = num1;
        }

        // Añade 7 al primo menor hasta llegar al mayor.
        for (int i = menor; i <= mayor; i += 7) {
            System.out.println(i);
        }

        sc.close();

    }
}
