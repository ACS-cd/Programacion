/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tienda;

import java.util.Scanner; 
/**
 *
 * @author ACS-cd
 */
public class SimuladorTienda {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in); //Declaración del escaner
        String userName;
        Double precioUnidad;
        final double IVA = 0.21; //Tener cuidado con empezar con mayúsculas, existe la posibilidad de confundir al programa con ellas.
        int unidad;
        Double subtotal;
        Double totalConIVA;
        System.out.println("Introduzca el nombre del cliente:");
               userName = sc.nextLine();
        System.out.println("Introduzca la seccion:");
               char letraSeccion = sc.next().charAt(0); //Si el escáner recoge un char, se debe usar .charAt y entre paréntesis el número de la letra que se quiere recoger, no tiene por qué ser siempre 0.
        System.out.println("Introduzca el número de unidades:");
               unidad = sc.nextInt();
        System.out.println("Introduzca el precio por unidad:");
               precioUnidad = sc.nextDouble(); 
        subtotal = unidad * precioUnidad;
        totalConIVA = subtotal * 1.21;
        
        boolean descuento = (unidad > 5 && totalConIVA > 50.0); // Usar && significa "y", siempre doble. Se puede usar boolean sin if and else en este caso.
        //En el editor usar PUNTO; en la terminal COMA.
        
        //Casting, cambiar el tipo de número - int puntos = (int)(totalConIVA); No funciona, preguntar al profesor.
        
        int puntos = new Double(totalConIVA).intValue(); //funciona
        
        System.out.println("Los datos encontrados son:");
        System.out.println("Nombre:" + userName);
        System.out.println("Seccion:" + letraSeccion);
        System.out.println("Subtotal:" + subtotal);
        System.out.println("Total con IVA:" + totalConIVA);
        System.out.println("Descuento aplicable:" + descuento);
        System.out.println("Puntos acumulados:" + puntos);
               sc.close();
            }
}
