package ud03;
import java.util.Scanner;
public class rombo {
    public static void main(String[] args) {
        //Igual que el triángulo, pero ahora imprimiendo la parte de abajo en números descendientes.
        Scanner sc = new Scanner(System.in);
        System.out.print("Introduzca un número: ");
        int num = sc.nextInt();

        // Parte ascendente
        for (int filas = 1; filas <= num; filas++) {
            for (int columnas = 1; columnas <= filas; columnas++) {
                System.out.print(filas);
            }
            System.out.println();
        }

        //Parte en descenso.
        for (int filas = num - 1; filas >= 1; filas--) { //Al contrario que en la primera parte.
            for (int columnas = 1; columnas <= filas; columnas++) { //Igual sea ascendente o descendente.
                System.out.print(filas);
            }
            System.out.println(); //Crea espacio hacia la siguiente línea.
        }
        sc.close();
    }
}