package ud03;

public class tabla {
    public static void main(String[] args) {
        for (int fila = 1; fila <= 5; fila++) {
            for (int columna = 1; columna<= 10; columna++) {
                System.out.print(fila * columna + "\t"); // barra invertida + t, es la forma de tabular horizontalmente en java; más limpio y rápido que espaciar de forma manual.
            }
            System.out.println(); //Crea espacio para que no salga todo en una sola línea. Cómo un salto a línea.
        }
    }
}
