package ud03;
import java.util.Scanner;
public class triangulo {
    public static void main(String[] args) {
      //Triángulo de números. Pide un número n y dibuja este triángulo (el ejemplo es con n = 4):
        Scanner sc = new Scanner(System.in);
        System.out.print("Introduzca un número: ");
        int num = sc.nextInt();

        for (int filas = 1; filas <= num; filas++) {
            //se cumple la condición hasta que filas es igual que num, porque según el ejemplo, el dato que introducimos es la base del triángulo.
            for (int columnas = 1; columnas <= filas; columnas++) {
                System.out.print(filas);
            }
            System.out.println();
        }
        sc.close();
    }
}
