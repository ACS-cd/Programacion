package ud05;
import java.util.Arrays;

public class Ej6Comprime {
    public static void main(String [] args) {
//Analiza un array de números y genera una representación comprimida que indique cada número y cuántas veces consecutivas aparece.

        int[] array1 = {4, 4, 4, 7, 7, 2, 5, 5, 5, 5};
        int contador = 1; //Empieza en 1 para contar el número si sale una vez.

            for (int i = 0; i < array1.length; i++) {
                if (i < array1.length -1 && array1[i] == array1[i + 1]) {
                    contador++;
                }
                else {
                    System.out.print(array1[i] + " x" + contador + " ");
                    contador = 1;
                }
            }
    }
}
