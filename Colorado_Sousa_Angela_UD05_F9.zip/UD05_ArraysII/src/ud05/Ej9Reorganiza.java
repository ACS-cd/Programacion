package ud05;
import java.util.Arrays;
import java.util.Scanner;

public class Ej9Reorganiza {
    public static void main(String [] args) {

       /*Pide 14 números enteros, que pueden ser positivos, negativos o cero. Reorganiza el array así:
        primero todos los números positivos;
        después todos los ceros;
        finalmente todos los negativos.
        Dentro de cada grupo debe mantenerse el orden original.  */

        Scanner sc = new Scanner(System.in);
        int[] array1 = new int[14];
        int[] auxiliar = new int[14];
        int posicion = 0;

        for (int i = 0; i < array1.length; i++) {
            System.out.print("Introduce un número positivo o negativo: ");
            array1[i] = sc.nextInt();
        }

        System.out.print("Array: ");
        for (int i = 0; i < array1.length; i++) {
            System.out.print(array1[i] + " ");
        }

        for (int i = 0; i < array1.length; i++) { //Números positivos.
            if (array1[i] > 0) {
                auxiliar[posicion] = array1[i];
                        posicion++;
            }
        }
        for (int i = 0; i < array1.length; i++) { //Ceros
            if (array1[i] == 0) {
                auxiliar[posicion] = array1[i];
                posicion++;

            }
        }
        for (int i = 0; i < array1.length; i++) { //Negativos
            if (array1[i] < 0) {
                auxiliar[posicion] = array1[i];
                posicion++;
            }
        }

        System.out.print("\nArray organizado: ");
        for (int i = 0; i < auxiliar.length; i++) {
            System.out.print(auxiliar[i] + " ");
        }

        sc.close();
    }
}
