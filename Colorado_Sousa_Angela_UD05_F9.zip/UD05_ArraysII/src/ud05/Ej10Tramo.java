package ud05;
import java.util.Arrays;
import java.util.Scanner;

public class Ej10Tramo {
    public static void main(String [] args) {

        /*Pide 12 números enteros que pueden ser positivos o negativos. Busca qué grupo de 3 elementos consecutivos tiene la mayor suma y muestra:

        los tres números;
        las posiciones que ocupan;
        la suma obtenida.
        Si hay varios tramos con la misma suma máxima, se conserva el primero que aparezca. */

       Scanner sc = new Scanner(System.in);
       int[] array1 = new int[12];
       int mayorSuma = array1[0] + array1[1] + array1[2];
       int posicion = 0;

       for(int i = 0; i < 12; i++){
           System.out.print("Introduce números enteros (positivos o negativos): ");
           array1[i] = sc.nextInt();
       }
       System.out.print("Array: ");
       for(int i = 0; i < 12; i++){
           System.out.print(array1[i] + " ");
       }

       for ( int i = 0; i < array1.length-2; i++){
           int suma = array1[i] + array1[i +1] + array1[i +2];

           if( suma > mayorSuma) {
               mayorSuma = suma;
               posicion = i;
           }
       }

       System.out.print("\nNúmeros: " + array1[posicion] + " " + array1[posicion+1] + " " + array1[posicion+2] + "\nPosiciones: " + posicion + " " + (posicion + 1) + " " + (posicion + 2) + "\nSuma: " + mayorSuma);
        sc.close();
    }
}
