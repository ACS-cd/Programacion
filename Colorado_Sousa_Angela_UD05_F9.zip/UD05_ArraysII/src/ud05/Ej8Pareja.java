package ud05;
import java.util.Arrays;
import java.util.Random;

public class Ej8Pareja {
    public static void main(String [] args) {
//Genera un array de 15 números enteros aleatorios entre 1 y 50. Encuentra los dos elementos consecutivos cuya suma sea mayor.
        Random r = new Random();
        int[] array1 = new int[15];

        for (int i = 0; i < array1.length; i++) {
            array1[i] = r.nextInt(50) + 1; //Si sale 0 se convierte en uno y siempre saldrá 50 cuando sea 49 + 1.
        }
        System.out.print("Array: ");
        for (int i = 0; i < array1.length; i++){
            System.out.print(array1[i] + " ");
        }

        int mayorSuma = array1[0] + array1[1];
        int posicion = 0;

        for ( int i = 0; i <array1.length -1; i++) {
            int suma = array1[i] + array1[i + 1];
            if ( suma > mayorSuma) {
                mayorSuma = suma;
                posicion = i;
            }
        }

        System.out.print("\nPareja: " + array1[posicion] + " " + array1[posicion+1] + "\nPosiciones: " + posicion + " " + (posicion + 1) + "\nSuma: " + mayorSuma);
    }
}
