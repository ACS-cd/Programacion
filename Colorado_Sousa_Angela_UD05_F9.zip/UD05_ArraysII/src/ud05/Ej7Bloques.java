package ud05;
import java.util.Arrays;
import java.util.Scanner;

public class Ej7Bloques {
    public static void main(String [] args) {
        //Pide 12 números y guárdalos en un array. Divide el array en tres bloques iguales de 4 elementos y cambia su posición.

        Scanner sc = new Scanner(System.in);
        int[] numeros = new int[12];
        int[] auxiliar = new int[12];

        for (int i = 0; i < numeros.length; i++){
            System.out.print("Introduce un número: ");
            numeros[i] = sc.nextInt();
        }

        System.out.print("Array original: ");
        for (int i = 0; i < numeros.length; i++) {
            System.out.print(numeros[i] + " ");
        }

        //Mover los bloques. Sumamos o restamos teniendo en cuenta las posiciones en las que están y queremos que acabe. Por ejemplo, si queremos cambiar numeros[0] al tercer bloque, sumamos 0 + 8 y este pasará a estar en el tercer bloque.
        for (int i = 0; i < numeros.length; i++) {
            if(i < 4) {
                auxiliar[i] = numeros[i + 8];
            } else if (i < 8) {
                auxiliar[i] = numeros[i - 4];
            } else {
                auxiliar[i] = numeros[i -4];
            }
        }

        System.out.print("\nArray cambiado: ");
        for(int i = 0; i < 12; i++){
            System.out.print(auxiliar[i] + " ");
        }
        sc.close();
    }
}
