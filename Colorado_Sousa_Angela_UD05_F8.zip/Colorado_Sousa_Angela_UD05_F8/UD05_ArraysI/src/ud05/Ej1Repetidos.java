package ud05;
import java.util.Scanner;
import java.util.Arrays;

public class Ej1Repetidos {
    public static void main(String[] args) {

    /*Pide 15 números enteros por teclado y guárdalos en un array. Después crea un segundo array que contenga únicamente los números que aparecen por primera vez, manteniendo el orden en el que se introdujeron. En el array final no puede haber ningún valor repetido */
        Scanner sc = new Scanner(System.in);
        int contador = 0;
        int[] array1 = new int[15];
        int[] sinRepe = new int[15];

        for (int i = 0; i < array1.length; i++) { //Array original, aquí se rellena para después comparar y dejar en el segundo los números sin repeticiones.
            System.out.print("Introduce el número " + (i+1) + " : ");
            array1[i] = sc.nextInt();
        }
        for (int i = 0; i < array1.length; i++) {
            boolean repetido = false;
            for (int j = 0; j < i; j++) {
                if (array1[i] == array1[j]) {
                    repetido = true;
                    break;
                }
            }
            if (!repetido) {
                sinRepe[contador] = array1[i];
                contador++;
            }
        }
        for (int i = 0; i < contador; i++) {
            System.out.print(sinRepe[i] + " ");
        }
    }
}
