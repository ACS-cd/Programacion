package ud05;
import java.util.Arrays;
import java.util.Scanner;

public class Ej3Ceros {
    public static void main(String[] args) {
        /*Pide 12 números enteros. Modifica el array de forma que todos los valores 0 queden al final, manteniendo el orden relativo de los demás elementos. No se puede ordenar el array.*/
        int[] array1 = new int[12];
        int[] array2 = new int[12];
        Scanner sc = new Scanner(System.in);
        int posicion = 0; //variable que indica la posición en la que los números se guardan dentro del array2.

        for (int i = 0; i < array1.length; i++) {
            System.out.print("Introduce el número entero " + (i + 1) + "º: ");
            array1[i] = sc.nextInt();
        }

        //Filtro numérico, si no es 0 = pasa al segundo array.
        for (int i = 0; i < array1.length; i++) {
            if (array1[i] != 0) {
                array2[posicion] = array1[i];
                posicion++;
            }
        }

        System.out.print("\nArray original: ");
        for (int i = 0; i < array1.length; i++) {
            System.out.print(array1[i] + " ");
        }
        System.out.print("\nArray modificado: ");
        for (int i = 0; i < array2.length; i++) {
            System.out.print(array2[i] + " ");
        }
    }
}

