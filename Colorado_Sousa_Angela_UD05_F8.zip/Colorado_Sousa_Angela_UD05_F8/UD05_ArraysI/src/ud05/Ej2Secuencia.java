package ud05;
import java.util.Arrays;
import java.util.Random;

public class Ej2Secuencia {
    public static void main(String[] args) {
        /*Genera un array de 20 números aleatorios entre 0 y 5. El programa debe localizar qué número aparece el mayor número de veces de forma consecutiva y mostrar:
        el número;
        cuántas veces aparece seguido;
        la posición donde empieza la secuencia. */

        int[] array1 = new int[20];
        Random aleaNum = new Random();
        int contador = 0;
        int contadorMax = 0;
        int lugar = 0;
        int numRepe = 0;

        for (int i = 0; i < array1.length; i++) { //Solo genera números de la longitud del array.
            array1[i] = aleaNum.nextInt(6);
        }

        System.out.print("Secuencia: ");
        for (int i = 0; i < array1.length; i++) { //Enseña los números
            System.out.print(array1[i] + " ");
        }

        //Compara el número actual con el anterior, si es igual el contador avanza uno. Si no, el contador se queda en 1 teniendo en cuenta ese número.
        for (int i = 1; i < array1.length; i++) {
            if (array1[i] == array1[i - 1]) {
                contador++;
            } else {
                contador = 1;
            }
            if (contador > contadorMax) { //Aquí se asegura siempre de guardar el contador con mayor valor.
                contadorMax = contador;
                numRepe = array1[i];
                lugar = i - contador + 1; //Calcula la posición de inicio de la secuencia. i es la posición en la que acaba la secuencia, se le resta el contador que son el número de veces repetidas (Sin embargo da error, se queda en el número anterior que no es parte de la secuencia, añadir 1 arregla este error.)
            }
        }

        System.out.print("\nNúmero que se repite más seguido: " + numRepe + "\nVeces consecutivas: " + contadorMax + "\nPosición inicial: " + lugar);
    }
}