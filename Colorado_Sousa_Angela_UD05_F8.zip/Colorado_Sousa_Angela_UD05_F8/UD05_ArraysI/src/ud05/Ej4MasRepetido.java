package ud05;
import java.util.Arrays;
import java.util.Random;

public class Ej4MasRepetido {
    public static void main (String [] args) {
        //Genera un array de 30 números aleatorios entre 1 y 10. Determina qué número aparece más veces y muestra todas las posiciones en las que aparece. Si hay empate entre varios números, se muestra el menor de ellos.
        Random randomNum = new Random();
        int[] array1 = new int[30];

        for(int i= 0; i < array1.length; i++) {
            array1[i] = randomNum.nextInt(10) + 1; //Se suma 1 para que los números sean de 1 al 10 y no de 0 a 10.
        }

        System.out.print("Array: ");
        for (int i = 0; i < array1.length; i++) {
            System.out.print(array1[i] + " ");
        }

        int[] repeticion = new int[11];
        for (int v : array1){
            repeticion[v]++;
        }
        int masRepe = 1;
        for(int v = 2; v <= 10; v++){
            if (repeticion[v] > repeticion[masRepe]){
                masRepe = v;
            }
        }

        System.out.print("\nNúmero más repetido: " + masRepe + " (" + repeticion[masRepe] + " veces)");
        System.out.print("\nPosiciones: ");
        for( int i = 0; i < array1.length; i++){
            if (array1[i] == masRepe) {
                System.out.print(i + " ");
            }
        }
    }
}
