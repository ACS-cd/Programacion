package ud05;
import java.util.Arrays;
import java.util.Scanner;

public class Ej5Inserta {
    public static void main (String[] args) {

        int[] array1 = new int[10];
        Scanner sc = new Scanner(System.in);

        for (int i = 0; i < array1.length-1; i++){
            System.out.print("\nIntroduce 9 números ordenados de mayor a menor: ");
            array1[i] = sc.nextInt();
        }
        System.out.print("\nArray original: ");
        for (int i = 0; i < array1.length-1; i++) {
            System.out.print(array1[i] + " ");
        }

        System.out.print("\nIntroduce un número nuevo: ");
        int numNuevo = sc.nextInt();
        int posicion = 8;
        while (posicion >= 0 && array1[posicion] > numNuevo) {
            //Mientras posicion sea mayor o igual que cero y posicion (dentro del array) sea mayor que el nuevo número introducido, este se desplazada una posición hacia a las izquierda, ya que empezamos por el final. Si fuese ordenado al revés, la opción de recorrido más óptimo sería a la inversa.
            array1[posicion +1] = array1[posicion];
            posicion--;
        }

        array1[posicion + 1] = numNuevo;

        System.out.print("Array final: ");
        for (int i = 0; i < array1.length; i++) {
            System.out.print(array1[i] + " ");
        }
    }
}
