package ud03;
import java.util.Scanner;
public class NotasCentinela {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Introduce una nota: ");
        double notas = sc.nextDouble();
        int descarte = 0;
        int valida = 0;

        while (notas != -1) {
            if (notas >= 0 && notas <= 10) {
                valida++;
            } else {
                descarte++;
            }
            System.out.print("Introduce una nota: ");
            notas = sc.nextDouble();
        }

        System.out.print("\nNotas válidas: " + valida + "\nNotas descartadas: " + descarte);
        sc.close();
    }
}
