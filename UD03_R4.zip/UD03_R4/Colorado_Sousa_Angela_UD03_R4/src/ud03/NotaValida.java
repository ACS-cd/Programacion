package ud03;
import java.util.Scanner;
public class NotaValida {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        double nota = 0;
        do {
            System.out.print("\nIntroduce la nota (0-10): ");
            nota = sc.nextDouble();

            if (nota < 0 || nota > 10) {
                System.out.print("\nNota no válida,inténtalo de nuevo.");
            }
        } while (nota < 0 || nota > 10);
        System.out.print("\nNota registrada: " + nota);
        sc.close();
    }
}
