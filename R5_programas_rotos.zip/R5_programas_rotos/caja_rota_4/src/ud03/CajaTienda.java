package ud03;

import java.util.Scanner;

public class CajaTienda {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int opcion = 0;
        double total = 0;
        int numVentas = 0;
        double mayor = 0;

        do {
            System.out.println("1 - Añadir venta");
            System.out.println("2 - Ver total y número de ventas");
            System.out.println("3 - Ver media por venta");
            System.out.println("4 - Ver la venta mayor");
            System.out.println("5 - FIN");
            System.out.print("Opcion: ");
            opcion = sc.nextInt();

            switch (opcion) {
                case 1:
                    System.out.print("Importe: ");
                    double importe = sc.nextDouble();
                    if (importe <= 0) {
                        System.out.println("El importe debe ser mayor que cero");
                    } else {
                        total = total + importe;
                        numVentas = numVentas + 1;
                        if (importe >= mayor) {
                            mayor = importe;
                        }
                    }
                    break;
                case 2:
                    System.out.println("Total: " + total);
                    System.out.println("Ventas: " + numVentas);
                    break;
                case 3:
                    if (numVentas == 0) {
                        System.out.println("Todavía no hay ventas");
                    } else {
                        System.out.println("Media: " + total / numVentas);
                    }
                    break;
                case 4:
                    if (numVentas == 0) {
                        System.out.println("Todavía no hay ventas");
                    } else {
                        System.out.println("Venta mayor: " + mayor);
                    }
                    break;
                case 5:
                    System.out.println("Ventas registradas: " + numVentas);
                    break;
                default:
                    System.out.println("Opcion no valida");
            }
        } while (opcion != 5);

        System.out.println("Programa terminado");
    }
}
