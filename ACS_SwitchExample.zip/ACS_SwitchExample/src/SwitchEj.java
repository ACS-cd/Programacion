import java.util.Scanner;

public class SwitchEj {
    public static void main(String[] args) {
        System.out.println("Introduce un número :");
        Scanner sc = new Scanner(System.in);
        int numero = sc.nextInt();
        switch ( numero )
        {
            case 1:
                System.out.println("Lunes");
                break;
            case 2:
                System.out.println("Martes");
                break;
            case 3:
                System.out.println("Miércoles");
                break;
            case 4:
                System.out.println("Jueves");
                break;

            default:
                System.out.println("Error. Día incorrecto.");
                break;
        }
    }
}


