package ud03;
import java.util.Scanner;
public class MenuCalculadora {
    public static void main(String[] args) {
/*Escribe, numerados, los pasos del programa completo en orden.
1. Iniciar.
2. Abrir bucle.
3. Mostrar el menú.
4. Pedir al usuario que elija un tipo de operación.
5. Pedir los números y en correspondencia hacer la operación seleccionada:
5.1. Pedir números y sumar
5.2 Pedir números y restar
5.3 Pedir números y multiplicar.
5.4 (Acotar que dividir entre 0 es inválido)
5.4.1. Pedir números y dividir.
6. Volver al menú.
7. Si el usuario elige fin
7.1. Fin del programa.
7.2. Si no, se repiten las instrucciones desde arriba.
         */
        Scanner sc = new Scanner(System.in);
        int menu = 0;//Declarar antes del bucle para que exista fuera del mismo.
        double numero1, numero2; // " " (lo mismo de arriba)

        while (menu != 5) { //el bucle debería funcionar hasta que se elige 5.
            System.out.print("\n1- Sumar.\n2- Restar.\n3- Multiplicar.\n4- Dividir.\n5- FIN.\nElige una opción:"); //Mostrar el menú y pedir tipo de operación.
            menu = sc.nextInt();

            switch (menu) {
                case 1: //Suma.
                    System.out.print("Introduce el primer número: ");
                    numero1 = sc.nextDouble();
                    System.out.print("Introduce el segundo número: ");
                    numero2 = sc.nextDouble();
                    System.out.print( numero1 + " + " + numero2 + " = " + (numero1 + numero2));
                    break;

                case 2: //Resta.
                    System.out.print("Introduce el primer número: ");
                    numero1 = sc.nextDouble();
                    System.out.print("Introduce el segundo número: ");
                    numero2 = sc.nextDouble();
                    System.out.print( numero1 + " - " + numero2 + " = " + (numero1 - numero2));
                    break;

                case 3: //Multiplicar
                    System.out.print("Introduce el primer número: ");
                    numero1 = sc.nextDouble();
                    System.out.print("Introduce el segundo número: ");
                    numero2 = sc.nextDouble();
                    System.out.print( numero1 + " * " + numero2 + " = " + (numero1 * numero2));
                    break;

                case 4: //Dividir
                    System.out.print("Introduce el primer número: ");
                    numero1 = sc.nextDouble();
                    System.out.print("Introduce el segundo número: ");
                    numero2 = sc.nextDouble();

                    if (numero2 == 0) {
                        System.out.print("Error. No es posible dividir entre O.\n");
                    } else {
                        System.out.print( numero1 + " / " + numero2 + " = " + (numero1 / numero2));
                    }
                    break;

                case 5: //Fin del bucle.
                    System.out.print("¡Adiós y muchas gracias!");
                    break;

                default: //Si se introduce un número fuera del rango del menú, error.
                    System.out.print("Número inválido.\n");
                    break;
            }
        }
        sc.close();
    }
}
