package ud03;
import java.util.Scanner;
public class ej3 {
    public static void main (String[] args) {
//El mayor de dos. Pide dos números y muestra cuál es el mayor; si son iguales, muestra Son iguales.
        Scanner sc = new Scanner(System.in);
        System.out.print("Introduce un número:");
        int numero1 = sc.nextInt();
        System.out.print("Introduce otro número:");
        int numero2 = sc.nextInt();
        if (numero1 > numero2) {
            System.out.print(numero1 + " es mayor que " + numero2);
        } else if (numero2 > numero1) {
            System.out.print(numero2 + " es mayor que " + numero1);
        }else {
            System.out.print(numero1 + " y " + numero2 + " son iguales.");
        }
        sc.close();
    }
}
