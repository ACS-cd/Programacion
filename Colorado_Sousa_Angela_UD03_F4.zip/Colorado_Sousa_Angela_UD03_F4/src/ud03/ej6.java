package ud03;
import java.util.Scanner;
public class ej6 {
    public static void main(String[] args) {
/*      Clasificación de una nota. Pide una nota de 0 a 10 (puede llevar decimales). Comprueba primero, con una condición que use &&, que la nota está entre 0 y 10: si no lo está, muestra Nota no valida y no clasifiques nada. Si es válida, clasifícala con una cadena if-else if-else: Suspenso (menos de 5), Aprobado (5 o 6), Notable (7 u 8) y Sobresaliente (9 o 10). Pruébala con 4.5, con 6 y con 9.5.
 */
        System.out.print("Introduce una nota: ");
        Scanner sc = new Scanner(System.in);
        double nota = sc.nextDouble();
        if (nota > 0 && nota <=10) {
            if (nota < 5) {
                System.out.print("Suspenso.");
            } else if (nota >= 5 && nota <= 6) {
                System.out.print("Aprobado.");
            } else if (nota >= 7 && nota <= 8 ) {
                System.out.print("Notable.");
            } else if (nota >= 9 && nota <=10) {
                System.out.print("Sobresaliente.");
            }
        } else {
            System.out.print("Nota no válida.");
        }
        sc.close();
    }
}
