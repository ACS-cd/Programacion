package ud03;
import java.util.Scanner;
public class ej5 {
    public static void main(String[] args) {
/*Año bisiesto. Pide un año y muestra El año es bisiesto o El año no es bisiesto. Un año es bisiesto si es divisible entre 4, excepto los que son divisibles entre 100, salvo que también sean divisibles entre 400. Usa el operador % y combina las condiciones con && y ||. Pruébalo con 2024, con 1900 y con 2000.
 */
    Scanner sc = new Scanner(System.in);
    System.out.print("Introduce un año: ");
    int years = sc.nextInt();
        if ((years % 4 == 0 && years % 100 != 0) || years % 400 == 0) {
                System.out.print("El año es bisiesto.");
        }else {
                System.out.print("El año no es bisiesto.");

        }
        sc.close();
    }
}
