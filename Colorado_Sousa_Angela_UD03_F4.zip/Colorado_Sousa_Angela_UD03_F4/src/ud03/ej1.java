package ud03;
import java.util.Scanner;
public class ej1 {
    public static void main(String[] args) {
//Mayor de edad (condicional simple). Pide la edad y muestra Eres mayor de edad solo si la edad es mayor o igual a 18. Si no lo es, no muestra nada.
        Scanner sc = new Scanner(System.in);
        System.out.print("Escribe tu edad:");
        int edad = sc.nextInt();
        if (edad >=18) {
            System.out.print("Eres mayor de edad.");
        }
        sc.close();
    }
}