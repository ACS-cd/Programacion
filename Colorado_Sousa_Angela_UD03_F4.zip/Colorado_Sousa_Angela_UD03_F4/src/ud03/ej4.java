package ud03;
import java.util.Scanner;
public class ej4 {
    public static void main(String[] args) {
        //El mayor de tres. Pide tres números distintos y muestra cuál es el mayor.
        Scanner sc = new Scanner(System.in);
        System.out.print("Introduce un número: ");
        int numero1 = sc.nextInt();
        System.out.print("Introduce otro número: ");
        int numero2 = sc.nextInt();
        System.out.print("Introduce un último número: ");
        int numero3 = sc.nextInt();
        if (numero1 > numero2 && numero1 > numero3) {
            System.out.print(numero1 + " es mayor que " + numero2  + " y " + numero3);
        } else if (numero2 > numero3 && numero2 > numero1) {
            System.out.print(numero2 + " es mayor que " + numero3 + " y " + numero1);
        } else {
            System.out.print(numero3 + " es mayor que " + numero1 + " y "+ numero2);
        }
        sc.close();
    }
}
