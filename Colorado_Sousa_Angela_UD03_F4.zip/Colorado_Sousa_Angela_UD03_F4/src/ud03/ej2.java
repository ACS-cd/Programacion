package ud03;
import java.util.Scanner;
public class ej2 {
    public static void main(String[] args) {
//Mayor o menor. Pide la edad y muestra Eres mayor de edad o Eres menor de edad (usa if-else).
        Scanner sc = new Scanner(System.in);
        System.out.print("Escribe tu edad:");
        int edad = sc.nextInt();
        if (edad >= 18) {
            System.out.print("Eres mayor de edad.");
        } else {
            System.out.print("Eres menor de edad.");
        }
        sc.close();
    }
}
