package ud03;
import java.util.Scanner;
public class CajaTienda {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int opcion = 0;
        int venta = 0;
        int total = 0;
        double media = 0;
        int ventaMayor = 0;
        int contador = 0;

        while (opcion != 5) {
            System.out.print("\n1- Añadir venta\n2- Ver total  y número de ventas\n3- Ver media por venta\n4- Ver la venta mayor\n5- FIN.\n");
            System.out.print("Seleccione opción: ");
            opcion = sc.nextInt();

            switch (opcion) {
                case 1:
                    System.out.print("\nIntroduce un importe: ");
                    venta = sc.nextInt();
                    total = total + venta;
                    contador++;
                    if (venta <= 0){
                        System.out.println("El importe debe ser mayor que cero.");
                    }
                    if (venta > ventaMayor) {
                        ventaMayor = venta;
                    }
                    break;
                case 2:
                    System.out.print("El total es " + total + " y se han hecho " + contador + " ventas.");
                    break;
                case 3:
                    if (contador == 0) {
                        System.out.println("Todavía no hay ventas.");
                    } else {
                        System.out.print("La media es: " + total/contador);
                    }
                    break;
                case 4:
                    if (ventaMayor == 0){
                        System.out.print("No hay venta mayor.");
                    } else {
                       System.out.print("La mayor venta fue de: " + ventaMayor);
                    }
                    break;
                case 5:
                    break;
                default:
                    System.out.print("Opción no válida.");
                    break;
            }
        }
        if (opcion == 5){
            System.out.print("Se han registrado " + venta + " ventas.");
        }
    }
}
