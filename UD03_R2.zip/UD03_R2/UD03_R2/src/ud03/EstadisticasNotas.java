package ud03;
import java.util.Scanner;
public class EstadisticasNotas {
    public static void main(String[] args){
        int contador = 0;
        double sumaNotas = 0;
        double notaMax = 0;
        double notaMin = 0;
        double media = 0;

        Scanner sc = new Scanner(System.in);
        System.out.print("Introduce una nota: ");
        double notas = sc.nextDouble();

        while (notas != -1) {

            if (contador == 0) { //Las primeras notas siempre van a ser la mínima y la máxima.
                notaMin = notas;
                notaMax = notas;
            } else { //Se intercambian si son mayores o menores que las notas ya guardadas.
                if (notas < notaMin) {
                        notaMin = notas;
                }
                if (notas > notaMax) {
                    notaMax = notas;
                }
            }

            sumaNotas += notas;
            contador++;

            System.out.print("Introduce una nota: ");
            notas = sc.nextDouble();
        }

        if (contador == 0){
            System.out.print("Notas leídas:" + contador + "\nMedia: no hay notas\nNota máxima: no hay notas\nNota mínima: no hay notas");
        } else {
            media = sumaNotas / contador;

            System.out.print("Notas leídas: " + contador);
            System.out.printf("\nMedia: %.2f", media);
            System.out.printf("\nNota máxima: %.2f", notaMax);
            System.out.printf("\nNota mínima: %.2f", notaMin);
        }
    }
}
